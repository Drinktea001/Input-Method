#include<iostream>
#include<fstream>
#include<string.h>
#include<sstream>  
#include<cstring>
#include<stdio.h>
#include<vector>
#include<map>
#include<queue>
#include <conio.h>
#include <windows.h>
#include <cstdlib>

using namespace std;


int inx = 0;
int iny = 2;
int outx = 0;
int outy = 12;
int optionx = 0;
int optiony = 22;
//inx��¼������ĺ����꣬outx��¼������ĺ�����,optionxΪѡ�����ĺ�����



class TrieNode
{
private:
	bool isWord;
	TrieNode* next[26];
	int cnt;         //�ýڵ㱻��ѯ����
public:
	TrieNode()
	{
		cnt = 0;
		isWord = false;
		memset(next, 0, sizeof(next));
	}

	void Insert(string word)	//����ĳ������
	{
		TrieNode* node = this;
		for (int i = 0; i < word.length(); i++)
		{
			char ch = word[i];
			if (node->next[ch - 'a'] == nullptr)
			{
				node->next[ch - 'a'] = new TrieNode();
			}
			node = node->next[ch - 'a'];
		}
		node->isWord = true;		//��������β������true
	}

	bool Search(string word)
	{
		TrieNode* node = this;
		for (int i = 0; i < word.length(); i++)
		{
			char ch = word[i];
			if (node->next[ch - 'a'] == nullptr)
			{
				return false;
			}
			node = node->next[ch - 'a'];
			node->cnt++;
		}
		return node->isWord;
	}

	bool StartWith(string prefix)			//����ǰ׺
	{
		TrieNode* node = this;
		for (int i = 0; i < prefix.length(); i++)
		{
			char ch = prefix[i];
			if (node->next[ch - 'a'] == nullptr)
			{
				return false;
			}
			node = node->next[ch - 'a'];
		}
		return true;
	}//
};
class Ime
{
public:
	map<string, string>word_sheet;
	map<string, int>word_frequency;
	Ime() {
		Add_Word();
		Add_Frequency();
	}
	int Add_Word()
	{
		char* buf = new char[2048];
		int len;
		ifstream istrm("pinyin.txt");
		if (!istrm.is_open())
		{
			cout << "failed to open fry" << endl;
		}

		while (1)
		{
			memset(buf, 0, sizeof(char) * 2048);
			istrm.getline(buf, sizeof(int) * 2048);
			string str(buf);
			len = str.find("=");
			string pinyin = str.substr(0, len);
			string font = str.substr(len + 1);
			word_sheet[pinyin] = font;
			if (istrm.eof())
				break;
		}
		istrm.close();
		delete[]buf;
		return 0;
	}
	int Add_Frequency()
	{
		char* buf = new char[2048];
		int len;
		ifstream istrm("fre.txt");
		if (!istrm.is_open())
		{
			cout << "failed to open fre" << endl;
		}

		while (1)
		{
			memset(buf, 0, sizeof(char) * 2048);
			istrm.getline(buf, sizeof(int) * 2048);
			string str(buf);
			if (str.find("=")==NULL) continue;
			len = str.find("=");
			string pinyin = str.substr(0, len);
			string freq = str.substr(len + sizeof(char));
			int freqi = stoi(freq);
			word_frequency[pinyin] = freqi;
			if (istrm.eof())
				break;
		}
		istrm.close();
		delete[]buf;
		return 0;
	}
	string getword(string a, int i) {
		stringstream s1;
		s1 << word_sheet[a].at(2 * (i - 1)) << word_sheet[a].at(2 * i - 1);
		return s1.str();
	}
};
void departor1(string pinyin, string& s2)//ֻ����ƴ����������������������ڼ����ո񣬴�Ϊ��һ��
{
	int i = 0;
	stringstream s1;
	for (i = 0; i < (int)pinyin.size(); i++)//����ĸ����
	{
		if (strchr("aeiouv", pinyin.at(i)))//������ĸ�Ƿ�ΪԪ������ΪԪ���������ǵ�Ԫ�����Ԫ������������ĸ�������ǰ���з�
		{
			if (i > 1 && (!strchr("xjghpyczsd", pinyin.at(i - 2))) && (strchr("aeiouv", pinyin.at(i - 1))) && strchr("ae", pinyin.at(i)))//8.10�޸ģ������з��硰�������ֵ���ĸ�� 8.11�������"xian""jiang"���������ڴʲ���Ҫ���з� 
				s1 << ' ' << pinyin.at(i);
			else
				s1 <<  pinyin.at(i);
			continue;//�����ϣ�continue��������ѭ��
		}
		else//����Ԫ������Ϊ����������������ĸ��Ҳ����Ԫ�������ĸ���硰ang����
		{
			if (pinyin.at(i) != 'n') // ������n���������壬��ֱ�ӿ�����ĸ
			{
				if (i == 0)//����һλ,����ָ�
				{
					s1 << pinyin.at(i);
				}
				else//�ǵ�һλ������ĸǰ�ָ
				{
					s1 << ' ' << pinyin.at(i);
				}
				if ( (pinyin.at(i) == 'z' || pinyin.at(i) == 'c' || pinyin.at(i) == 's') &&(pinyin.at(i + 1) == 'h')&& (i + 1) < (int)pinyin.size())//����λ�ж���ĸ��zcs����zhchsh
				{
					s1 << pinyin.at(i + 1);
					i++;//����ǰ������һ�ַ���ֱ����ǰ����һλ
				}
				continue;
			}
			else                 //��n,�������壬���һ���жϣ��ж����ݣ���n����ĸ�����������壬һ����an angһ�࣬��Ϊ��ĸ�����һ������ĸ
			{
				if (i == (int)pinyin.size() - 1)//�����һλ��һ������ĸ
				{
					s1 << pinyin.at(i);
					continue;
				}
				else
					i++;   //���ǣ�����һλ

				if (strchr("aeiouv", pinyin.at(i)))   //�����һλ��Ԫ��,˵��nһ������ĸ����nǰ�и�
				{
					if (i == 1)//ͬ�ϣ���ĸ�Ƿ�Ϊ��һλ�ж�
					{
						s1 << 'n' << pinyin.at(i);
						continue;
					}
					else
					{
						s1 << ' ' << 'n' << pinyin.at(i);
						continue;
					}
				}
				else//��Ϊ��ĸ����Ϊ��ĸ�����ж�Ϊ��xn�����ǡ�xng��
				{
					if (pinyin.at(i) == 'g')//��Ϊg�����ǡ�xng������xn g��
					{
						if (i == (int)pinyin.size() - 1)//ͬ�ϣ����һλ������ĸ
						{
							s1 << 'n' << pinyin.at(i);
							continue;
						}
						else//���ǣ��ٿ�һλ
							i++;  //�������

						if (strchr("aeiouv", pinyin.at(i)))//ͬ�ϣ���һλ��ĸ��������ĸ
						{
							s1 << 'n' << ' ' << 'g' << pinyin.at(i);
							continue;
						}
						else//������ĸ������ĸ���ұ�Ϊ��xng��
						{
							s1 << 'n' << 'g' << ' ' << pinyin.at(i);
							continue;
						}
					}
					else   //��Ϊ�������������Ϊ��xn��
					{
						s1 << 'n' << ' ' << pinyin.at(i);
						if ((i + 1) < (int)pinyin.size() && (pinyin.at(i) == 'z' || pinyin.at(i) == 'c' || pinyin.at(i) == 's') &&(pinyin.at(i + 1) == 'h'))//�����Ҳ���n��g,�������zcs��ʣ����������������zcs����Ϊzhchsh�����һ���ж�
						{
							s1 << 'h';
							i++;
						}
						continue;
					}
				}
			}
		}
	}
	s1 << ' ';
	s2 = s1.str();
}//���⣺�硰������ƴ��Ϊ��ji ang������jiang��������壬�޷�����

void departor2(string pinyin, string& ss)
{
	TrieNode trie;
	{
		trie.Insert("a");
		trie.Insert("ai");
		trie.Insert("an");
		trie.Insert("ang");
		trie.Insert("ao");
		trie.Insert("b");
		trie.Insert("ba");
		trie.Insert("bai");
		trie.Insert("ban");
		trie.Insert("bang");
		trie.Insert("bao");
		trie.Insert("bei");
		trie.Insert("be");
		trie.Insert("ben");
		trie.Insert("beng");
		trie.Insert("bi");
		trie.Insert("bia");
		trie.Insert("bian");
		trie.Insert("biao");
		trie.Insert("bie");
		trie.Insert("bin");
		trie.Insert("bing");
		trie.Insert("bo");
		trie.Insert("bu");
		trie.Insert("c");
		trie.Insert("ca");
		trie.Insert("cai");
		trie.Insert("can");
		trie.Insert("cang");
		trie.Insert("cao");
		trie.Insert("ce");
		trie.Insert("cen");
		trie.Insert("ceng");
		trie.Insert("ch");
		trie.Insert("cha");
		trie.Insert("chai");
		trie.Insert("chan");
		trie.Insert("chang");
		trie.Insert("chao");
		trie.Insert("che");
		trie.Insert("chen");
		trie.Insert("cheng");
		trie.Insert("chi");
		trie.Insert("cho");
		trie.Insert("chon");
		trie.Insert("chong");
		trie.Insert("chou");
		trie.Insert("chu");
		trie.Insert("chua");
		trie.Insert("chuai");
		trie.Insert("chuan");
		trie.Insert("chuang");
		trie.Insert("chui");
		trie.Insert("chun");
		trie.Insert("chuo");
		trie.Insert("ci");
		trie.Insert("co");
		trie.Insert("con");
		trie.Insert("cong");
		trie.Insert("cou");
		trie.Insert("cu");
		trie.Insert("cua");
		trie.Insert("cuan");
		trie.Insert("cui");
		trie.Insert("cun");
		trie.Insert("cuo");
		trie.Insert("d");
		trie.Insert("da");
		trie.Insert("dai");
		trie.Insert("dan");
		trie.Insert("dang");
		trie.Insert("dao");
		trie.Insert("de");
		trie.Insert("dei");
		trie.Insert("den");
		trie.Insert("deng");
		trie.Insert("di");
		trie.Insert("dia");
		trie.Insert("dian");
		trie.Insert("diao");
		trie.Insert("die");
		trie.Insert("din");
		trie.Insert("ding");
		trie.Insert("diu");
		trie.Insert("dong");
		trie.Insert("don");
		trie.Insert("do");
		trie.Insert("dou");
		trie.Insert("du");
		trie.Insert("dua");
		trie.Insert("duan");
		trie.Insert("dui");
		trie.Insert("dun");
		trie.Insert("duo");
		trie.Insert("e");
		trie.Insert("ei");
		trie.Insert("en");
		trie.Insert("er");
		trie.Insert("f");
		trie.Insert("fe");
		trie.Insert("fa");
		trie.Insert("fan");
		trie.Insert("fang");
		trie.Insert("fei");
		trie.Insert("fen");
		trie.Insert("feng");
		trie.Insert("fo");
		trie.Insert("fou");
		trie.Insert("fu");
		trie.Insert("g");
		trie.Insert("ga");
		trie.Insert("gai");
		trie.Insert("gan");
		trie.Insert("gang");
		trie.Insert("gao");
		trie.Insert("ge");
		trie.Insert("gei");
		trie.Insert("gen");
		trie.Insert("geng");
		trie.Insert("go");
		trie.Insert("gon");
		trie.Insert("gong");
		trie.Insert("gou");
		trie.Insert("gu");
		trie.Insert("gua");
		trie.Insert("guai");
		trie.Insert("guan");
		trie.Insert("guang");
		trie.Insert("gu");
		trie.Insert("gui");
		trie.Insert("gun");
		trie.Insert("guo");
		trie.Insert("h");
		trie.Insert("ha");
		trie.Insert("hai");
		trie.Insert("han");
		trie.Insert("hang");
		trie.Insert("hao");
		trie.Insert("he");
		trie.Insert("hei");
		trie.Insert("hen");
		trie.Insert("ho");
		trie.Insert("hon");
		trie.Insert("heng");
		trie.Insert("hong");
		trie.Insert("hou");
		trie.Insert("hu");
		trie.Insert("hua");
		trie.Insert("huai");
		trie.Insert("huan");
		trie.Insert("huang");
		trie.Insert("hui");
		trie.Insert("hun");
		trie.Insert("huo");
		trie.Insert("j");
		trie.Insert("ji");
		trie.Insert("jia");
		trie.Insert("jian");
		trie.Insert("jiang");
		trie.Insert("jiao");
		trie.Insert("jie");
		trie.Insert("jin");
		trie.Insert("jing");
		trie.Insert("jio");
		trie.Insert("jion");
		trie.Insert("jiong");
		trie.Insert("jiu");
		trie.Insert("ju");
		trie.Insert("jua");
		trie.Insert("juan");
		trie.Insert("jue");
		trie.Insert("jun");//
		trie.Insert("k");
		trie.Insert("ka");
		trie.Insert("kai");
		trie.Insert("kan");
		trie.Insert("kang");
		trie.Insert("kao");
		trie.Insert("ke");
		trie.Insert("ken");
		trie.Insert("keng");
		trie.Insert("ko");
		trie.Insert("kon");
		trie.Insert("kong");
		trie.Insert("kou");
		trie.Insert("ku");
		trie.Insert("kua");
		trie.Insert("kuai");
		trie.Insert("kuan");
		trie.Insert("kuang");
		trie.Insert("kui");
		trie.Insert("kun");
		trie.Insert("kuo");
		trie.Insert("l");
		trie.Insert("la");
		trie.Insert("lai");
		trie.Insert("lan");
		trie.Insert("lang");
		trie.Insert("lao");
		trie.Insert("le");
		trie.Insert("len");
		trie.Insert("lei");
		trie.Insert("leng");
		trie.Insert("li");
		trie.Insert("lia");
		trie.Insert("lian");
		trie.Insert("liang");
		trie.Insert("liao");
		trie.Insert("lie");
		trie.Insert("lin");
		trie.Insert("ling");
		trie.Insert("liu");
		trie.Insert("lo");
		trie.Insert("lon");
		trie.Insert("long");
		trie.Insert("lou");
		trie.Insert("lu");
		trie.Insert("lv");
		trie.Insert("luan");
		trie.Insert("lue");
		trie.Insert("lun");
		trie.Insert("luo");
		trie.Insert("m");//
		trie.Insert("ma");
		trie.Insert("mai");
		trie.Insert("man");
		trie.Insert("mang");
		trie.Insert("mao");
		trie.Insert("me");
		trie.Insert("mei");
		trie.Insert("men");
		trie.Insert("meng");
		trie.Insert("mi");
		trie.Insert("mia");
		trie.Insert("mian");
		trie.Insert("miao");
		trie.Insert("mie");
		trie.Insert("min");
		trie.Insert("ming");
		trie.Insert("miu");
		trie.Insert("mo");
		trie.Insert("mou");
		trie.Insert("mu");
		trie.Insert("n");
		trie.Insert("na");
		trie.Insert("nai");
		trie.Insert("nan");
		trie.Insert("nang");
		trie.Insert("nao");
		trie.Insert("ne");
		trie.Insert("nei");
		trie.Insert("nen");
		trie.Insert("neng");
		trie.Insert("ni");
		trie.Insert("nia");
		trie.Insert("nian");
		trie.Insert("niang");
		trie.Insert("niao");
		trie.Insert("nie");
		trie.Insert("nin");
		trie.Insert("ning");
		trie.Insert("niu");
		trie.Insert("no");
		trie.Insert("non");
		trie.Insert("nong");
		trie.Insert("nou");
		trie.Insert("nu");
		trie.Insert("nv");
		trie.Insert("nua");
		trie.Insert("nuan");
		trie.Insert("nue");
		trie.Insert("nuo");
		trie.Insert("o");
		trie.Insert("ou");
		trie.Insert("p");
		trie.Insert("pa");
		trie.Insert("pai");
		trie.Insert("pan");
		trie.Insert("pang");
		trie.Insert("pao");
		trie.Insert("pe");
		trie.Insert("pei");
		trie.Insert("pen");
		trie.Insert("peng");
		trie.Insert("pi");
		trie.Insert("pia");
		trie.Insert("pian");
		trie.Insert("piao");
		trie.Insert("pie");
		trie.Insert("pin");
		trie.Insert("ping");
		trie.Insert("po");
		trie.Insert("pou");
		trie.Insert("pu");
		trie.Insert("q");//
		trie.Insert("qi");
		trie.Insert("qia");
		trie.Insert("qian");
		trie.Insert("qiang");
		trie.Insert("qiao");
		trie.Insert("qie");
		trie.Insert("qin");
		trie.Insert("qing");
		trie.Insert("qiu");
		trie.Insert("qio");
		trie.Insert("qion");
		trie.Insert("qiong");
		trie.Insert("qu");
		trie.Insert("qua");
		trie.Insert("quan");
		trie.Insert("que");
		trie.Insert("qun");
		trie.Insert("r");
		trie.Insert("ra");
		trie.Insert("ran");
		trie.Insert("rang");
		trie.Insert("rao");
		trie.Insert("re");
		trie.Insert("ren");
		trie.Insert("reng");
		trie.Insert("ri");
		trie.Insert("ro");
		trie.Insert("ron");
		trie.Insert("rong");
		trie.Insert("rou");
		trie.Insert("ru");
		trie.Insert("rua");
		trie.Insert("ruan");
		trie.Insert("rui");
		trie.Insert("run");
		trie.Insert("ruo");
		trie.Insert("s");
		trie.Insert("sa");
		trie.Insert("sai");
		trie.Insert("san");
		trie.Insert("sang");
		trie.Insert("sao");
		trie.Insert("se");
		trie.Insert("sen");
		trie.Insert("seng");
		trie.Insert("sh");
		trie.Insert("sha");
		trie.Insert("shai");
		trie.Insert("shan");
		trie.Insert("shang");
		trie.Insert("shao");
		trie.Insert("she");
		trie.Insert("shei");
		trie.Insert("shen");
		trie.Insert("sheng");
		trie.Insert("shi");
		trie.Insert("sho");
		trie.Insert("shou");
		trie.Insert("shu");
		trie.Insert("shua");
		trie.Insert("shuai");
		trie.Insert("shuan");
		trie.Insert("shuang");
		trie.Insert("shui");
		trie.Insert("shun");
		trie.Insert("shuo");
		trie.Insert("si");
		trie.Insert("so");
		trie.Insert("son");
		trie.Insert("song");
		trie.Insert("sou");
		trie.Insert("su");
		trie.Insert("sua");
		trie.Insert("suan");
		trie.Insert("sui");
		trie.Insert("sun");
		trie.Insert("suo");
		trie.Insert("t");
		trie.Insert("ta");
		trie.Insert("tai");
		trie.Insert("tan");
		trie.Insert("tang");
		trie.Insert("tao");
		trie.Insert("te");
		trie.Insert("ten");
		trie.Insert("teng");
		trie.Insert("ti");
		trie.Insert("tia");
		trie.Insert("tian");
		trie.Insert("tiao");
		trie.Insert("tie");
		trie.Insert("tin");
		trie.Insert("ton");
		trie.Insert("to");
		trie.Insert("ting");
		trie.Insert("tong");
		trie.Insert("tou");
		trie.Insert("tu");
		trie.Insert("tua");
		trie.Insert("tuan");
		trie.Insert("tui");
		trie.Insert("tun");
		trie.Insert("tuo");
		trie.Insert("w");
		trie.Insert("wa");
		trie.Insert("wai");
		trie.Insert("wan");
		trie.Insert("wang");
		trie.Insert("we");
		trie.Insert("wei");
		trie.Insert("wen");
		trie.Insert("weng");
		trie.Insert("wo");
		trie.Insert("wu");
		trie.Insert("x");
		trie.Insert("xi");
		trie.Insert("xia");
		trie.Insert("xiao");
		trie.Insert("xian");
		trie.Insert("xiang");
		trie.Insert("xie");
		trie.Insert("xin");
		trie.Insert("xing");
		trie.Insert("xio");
		trie.Insert("xion");
		trie.Insert("xiong");
		trie.Insert("xiu");
		trie.Insert("xu");
		trie.Insert("xua");
		trie.Insert("xuan");
		trie.Insert("xue");
		trie.Insert("xun");
		trie.Insert("y");
		trie.Insert("ya");
		trie.Insert("yan");
		trie.Insert("yang");
		trie.Insert("yao");
		trie.Insert("ye");
		trie.Insert("yi");
		trie.Insert("yin");
		trie.Insert("ying");
		trie.Insert("yo");
		trie.Insert("yon");
		trie.Insert("yong");
		trie.Insert("you");
		trie.Insert("yu");
		trie.Insert("yua");
		trie.Insert("yuan");
		trie.Insert("yue");
		trie.Insert("yun");
		trie.Insert("z");
		trie.Insert("za");
		trie.Insert("zai");
		trie.Insert("zan");
		trie.Insert("zang");
		trie.Insert("zao");
		trie.Insert("ze");
		trie.Insert("zei");
		trie.Insert("zen");
		trie.Insert("zeng");
		trie.Insert("zh");
		trie.Insert("zha");
		trie.Insert("zhai");
		trie.Insert("zhan");
		trie.Insert("zhang");
		trie.Insert("zhao");
		trie.Insert("zhe");
		trie.Insert("zhen");
		trie.Insert("zheng");
		trie.Insert("zhi");
		trie.Insert("zho");
		trie.Insert("zhon");
		trie.Insert("zhong");
		trie.Insert("zhou");
		trie.Insert("zhu");
		trie.Insert("zhua");
		trie.Insert("zhuai");
		trie.Insert("zhuan");
		trie.Insert("zhuang");
		trie.Insert("zhui");
		trie.Insert("zhun");
		trie.Insert("zhuo");
		trie.Insert("zi");//
		trie.Insert("zo");
		trie.Insert("zon");
		trie.Insert("zong");
		trie.Insert("zou");
		trie.Insert("zu");
		trie.Insert("zua");
		trie.Insert("zuan");
		trie.Insert("zui");
		trie.Insert("zun");
		trie.Insert("zuo");
	}
	//�洢�Ϸ��ַ�
	int i ;
	stringstream s1,s2,s3;
	for (i = 0; i < (int)pinyin.size(); i++)
	{
		if (pinyin.at(i) == '/') { s2 << " "; continue; }
		s2 << pinyin.at(i);
		if ((!trie.Search(s2.str())))//����������i����ĸ�����ڷǷ���˵��¼�����ĸǰΪ���Ч����
		{
			if (s1.str().empty()) s1 << s3.str();
			else s1 << " " << s3.str();
			s2.str("");
			s3.str("");
			s2 << pinyin.at(i);
		}
		if (i == (int)pinyin.size() - 1) {
			if (s1.str().empty()) s1 << s2.str();
			else s1 << " " << s2.str();
		}
		s3 << pinyin.at(i);
	}
	s1 << " ";
	ss = s1.str();
}



void BackgroundColor()
{
	system("color f0");
}
void ChangePosition(int x, int y)
{
	HANDLE hOUT;
	COORD pos = { 0,0 };
	pos.X = x;
	pos.Y = y;
	hOUT = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hOUT, pos);
}
void InitialInterface()
{
	ChangePosition(1, 1);
	cout << "����:" << endl;
	ChangePosition(1, 11);
	cout << "���:" << endl;
	ChangePosition(1, 21);
	cout << "ѡ��:" << endl;
}
void ClearInput()                  //ѡ�ʺ������ƴ�����
{
	int inputcnt = 2;		//��2�п�ʼ���
	for (inputcnt; inputcnt < 9; inputcnt++)
	{
		ChangePosition(0, inputcnt);
		cout << "                                                                                                                               ";
	}
	inx = 0;
	iny = 2;
	ChangePosition(inx, iny);
}
void ClearOption()                  //ѡ�ʺ������ƴ�����
{
	int optioncnt = 22;   //��22�п�ʼ���
	for (optioncnt; optioncnt < 26; optioncnt++)
	{
		ChangePosition(0, optioncnt);
		cout << "                                                                                                                                               ";
	}
	int temp_optionx = 0;
	int temp_optiony = 22;
	ChangePosition(temp_optionx, temp_optiony);
	optionx = 0;
	optiony = 22;
}



int main()
{
	BackgroundColor();
	InitialInterface();


	int chosecnt = 0;   //��¼�ֺõ�����ѡ���˼��ζ�Ӧ���ֻ�ʣ����������ڱ�ѡ��󣬳�ʼ��
	int cnt = 0;
	Ime ime;
	char a1[100]="";
	char inputch;

	int judge = 0;
	int chose = 0;
	string str_temp[100];
	string b1;
	string& b2 = b1;
	string pyz[100];

	stringstream s1;

	while (1)
	{



		int ptr = 0, j = 0;
		int yinjiecnt = 0;  //��¼�����ƴ�������Էֳɼ�������

		inputch = _getch();
		ChangePosition(inx, iny);
		if ('a' <=inputch && inputch <= 'z')
		{
			cout << inputch;
		}

		inx++;
		//cout << "inputch= " << inputch << endl;
		a1[cnt] = inputch;
		//cout << "a1["<<cnt<<"]= " << a1[cnt] << endl;
		cnt++;
	

		//if (judge)
		//{
		//	if (yinjiecnt == chosecnt)
		//	{
		//		cout << "��ƴ����ѡ��" << endl;
		//		chosecnt = 0;
		//	}

		//}
		//judge++;

		//cout << "b2= " << b2 << endl;
		switch (inputch)
		{
		case 'a':
		case 'b':
		case 'c':
		case 'd':
		case 'e':
		case 'f':
		case 'g':
		case 'h':
		case 'i':
		case 'j':
		case 'k':
		case 'l':
		case 'm':
		case 'n':
		case 'o':
		case 'p':
		case 'q':
		case 'r':
		case 's':
		case 't':
		case 'u':
		case 'v':
		case 'w':
		case 'x':
		case 'y':
		case 'z':
		{
			ClearOption();
			departor2(a1, b2);
			for (int i = 0; i < (int)b2.size(); i++)
			{
				if (b2[i] != ' ')
				{
					s1 << b2.at(i);
					ptr++;
				}
				else
				{
					pyz[j] = s1.str();
					s1.str("");
					ptr = 0;
					j++;
				}
			}
			
			//for (int cnt_isyinjie = 0; cnt_isyinjie<100; cnt_isyinjie++)
			//{
			//	if (pyz[cnt_isyinjie].length() != 0)
			//	{
			//		yinjiecnt++;
			//	}
			//}

			//cout << "yinjiecnt=" << yinjiecnt << endl;

			//for (int temp = 0; temp < 10; temp++)
			//{
			//	if (pyz[temp].length() != 0)
			//	{
			//		cout << "pyz["<<temp << "]= " << pyz[temp] << endl;
			//		str_temp[temp] = pyz[temp];
			//	}
			//}


			if (!pyz[1].empty()) {
				//����Ϊά�ر��㷨
				string w, w0, wi; int freq = 0;
				for (int i = 0; !pyz[i + 1].empty(); i++)
				{
					string ww;
					for (int j = 1; ime.word_sheet[pyz[i]].at(2 * j - 2) != '0'; j++) 
					{
						string w1;
						if (i == 0) w1 = ime.getword(pyz[i], j);
						else w1 = wi;
						for (int k = 1; ime.word_sheet[pyz[i + 1]].at(2 * k - 2) != '0'; k++)
						{
							string w2 = ime.getword(pyz[i + 1], k);
							ww = w1 + w2;
							if (!ime.word_frequency.count(ww)) continue;
							if (freq == 0) freq = ime.word_frequency[ww];
							if (ime.word_frequency[ww] >= freq)
							{
								w0 = ww; freq = ime.word_frequency[ww]; wi = ime.getword(pyz[i + 1], k);
							}
						}
					}freq = 0;

					if (i == 0) w = w0;
					else w = w + wi;
				}



				for (int i = 0; !pyz[i].empty(); i++)
				{
					ChangePosition(optionx, optiony);

					if (i == 0) cout << "1." << w << " ";
					for (int k = 1; ime.word_sheet[pyz[i]].at(2 * k - 2) != '0'&&k<7; k++)
					{

						if (i == 0)
						{
							cout << k + 1 << "." << ime.getword(pyz[i], k) << " ";

						}
						else
						{
							cout << k << "." << ime.getword(pyz[i], k) << " ";

						}
					}
					optiony++;
					cout << endl;
					if (0)
					{
						int j;
						cin >> j;

						if (j == 1 && i == 0)
						{
							s1 << w; break;
						}
						else if (i == 0) s1 << ime.getword(pyz[i], j - 1);
						else s1 << ime.getword(pyz[i], j);
					}

				}
			}
			else {
				ChangePosition(optionx, optiony);
				for (int k = 1; ime.word_sheet[pyz[0]].at(2 * k - 2) != '0' && k < 7; k++)
				{
					cout << k << "." << ime.getword(pyz[0], k) << " ";
				}
				optiony++;
				cout << endl;

				//�����ܷ��Ȳ�����
				if (0)
				{
					int j;
					cin >> j;
					s1 << ime.getword(pyz[0], j);
				}

			}
			//cout << s1.str();


			break;
		}
		case '1':
		{
			
			//cout << str1;

			//Clear();
			ChangePosition(outx, outy);
			cout << ime.getword(pyz[chose], 1) << endl;
			outx = outx + ime.getword(pyz[chose], 1).length();
			chosecnt++;
			chose++;
			ChangePosition(0, 21 + chosecnt);
			cout << "                                                                                                          ";
			//cout << "chosecnt=" << chosecnt << endl;

			break;
		}
		case '2':
		{
			//ChangePosition(outx, outy);
			//cout << str2;
			//outx = outx + str1.length();
			ChangePosition(outx, outy);
			cout << ime.getword(pyz[chose], 2) << endl;
			outx = outx + ime.getword(pyz[chose], 1).length();
			chose++;
			chosecnt++;
			ChangePosition(0, 21 + chosecnt);
			cout << "                                                                                                          ";
			break;
		}
		case '3':
		{
			//ChangePosition(outx, outy);
			//cout << str3;
			//outx = outx + str1.length();
			ChangePosition(outx, outy);
			cout << ime.getword(pyz[chose], 3) << endl;
			outx = outx + ime.getword(pyz[chose], 1).length();
			chose++;
			chosecnt++;
			ChangePosition(0, 21 + chosecnt);
			cout << "                                                                                                          ";
			break;
		}
		case '4':
		{
			//ChangePosition(outx, outy);
			//cout << str4;
			//outx = outx + str1.length();
			ChangePosition(outx, outy);
			cout << ime.getword(pyz[chose], 4) << endl;
			outx = outx + ime.getword(pyz[chose], 1).length();
			chose++;
			chosecnt++;
			ChangePosition(0, 21 + chosecnt);
			cout << "                                                                                                          ";
			break;
		}
		case '5':
		{
			//ChangePosition(outx, outy);
			//cout << str5;
			//outx = outx + str1.length();
			ChangePosition(outx, outy);
			cout << ime.getword(pyz[chose], 5) << endl;
			outx = outx + ime.getword(pyz[chose], 1).length();
			chose++;
			chosecnt++;
			ChangePosition(0, 21 + chosecnt);
			cout << "                                                                                                          ";
			break;
		}
		case '6':
		{
			//ChangePosition(outx, outy);
			//cout << str4;
			//outx = outx + str1.length();
			ChangePosition(outx, outy);
			cout << ime.getword(pyz[chose], 6) << endl;
			outx = outx + ime.getword(pyz[chose], 1).length();
			chose++;
			chosecnt++;
			ChangePosition(0, 21 + chosecnt);
			cout << "                                                                                                          ";
			break;
		}
		case '7':
		{
			//ChangePosition(outx, outy);
			//cout << str4;
			//outx = outx + str1.length();
			ChangePosition(outx, outy);
			cout << ime.getword(pyz[chose], 7) << endl;
			outx = outx + ime.getword(pyz[chose], 1).length();
			chose++;
			chosecnt++;
			ChangePosition(0, 21 + chosecnt);
			cout << "                                                                                                          ";
			break;
		}

		case '\b':
		{
			if (inx == 0 && iny == 2)                           //�����ص������ʼλ�ú�ɾ�������ʾ����
			{
				if (outx == 0 && outy == 12)
				{

				}
				else
				{
					int cnt1 = 12;
					for (cnt1; cnt1 < 21; cnt1++)
					{
						ChangePosition(0, cnt1);
						cout << "                                                                                                                      ";
						outx = 0;
						outy = 12;
					}
				}
			}
			else									//����겻������ĳ�ʼλ��ʱ����ɾ��������ʾ������
			{
				inx--;
				a1[cnt] = ' ';
				if (cnt > 0)
				{
					cnt--;
				}
				ChangePosition(inx, iny);
				cout << " ";

			}
		}

		case ',':
		{			
			int cnt = 0;
			char a1[100] = "";

			string str_temp[100];
			string b1;
			string& b2 = b1;
			string pyz[100];

			stringstream s1;
			ClearInput();
			int cnt1 = 12;
			for (cnt1; cnt1 < 21; cnt1++)
			{
				ChangePosition(0, cnt1);
				cout << "                                                                                                                      ";
				outx = 0;
				outy = 12;
			}
			ClearOption();
		}
		default:
		{
			break;
		}


		{
			if (inx == 100)
			{
				iny++;
				inx = 0;
			}
			else if (inx == 0 && iny != 2)
			{
				iny--;
				inx = 100;
			}
			else if (outx > 100)
			{
				outy++;
				outx = 0;
			}
			else if (outx == 0 && outy != 12)
			{
				outx = 100;
				outy--;
			}


		}


		}









	}

	return 0;
}